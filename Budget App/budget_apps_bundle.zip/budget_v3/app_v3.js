// app_v3.js – recurring transactions + risk analysis

const STORAGE_KEY_V3 = 'budgetV3_state';
const PASS_KEY_V3 = 'budgetV3_masterHash';

let state = {
  accounts: [],
  transactions: [], // {id,dateISO,description,category,accountId,amount,isPlanned,recurrence}
  settings: {
    forecastDays: 90,
    warningBuffer: 500
  }
};

// ---------- SHA-256 ----------
async function sha256(text) {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ---------- Persistence ----------
function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY_V3);
  if (!raw) return;
  try {
    const parsed = JSON.parse(raw);
    state = Object.assign(state, parsed);
  } catch (e) {
    console.error('Failed to parse V3 state', e);
  }
}
function saveState() {
  localStorage.setItem(STORAGE_KEY_V3, JSON.stringify(state));
}

// ---------- Auth ----------
const authScreen = document.getElementById('authScreen');
const authTitle = document.getElementById('authTitle');
const authMessage = document.getElementById('authMessage');
const setPasswordSection = document.getElementById('setPasswordSection');
const loginSection = document.getElementById('loginSection');
const newPasswordInput = document.getElementById('newPassword');
const newPasswordConfirmInput = document.getElementById('newPasswordConfirm');
const setPasswordBtn = document.getElementById('setPasswordBtn');
const loginPasswordInput = document.getElementById('loginPassword');
const loginBtn = document.getElementById('loginBtn');

async function initAuth() {
  const hash = localStorage.getItem(PASS_KEY_V3);
  if (!hash) {
    authTitle.textContent = 'Set Master Password';
    authMessage.textContent = 'Choose a password to lock your budget on this device.';
    setPasswordSection.classList.remove('hidden');
    loginSection.classList.add('hidden');
  } else {
    authTitle.textContent = 'Locked';
    authMessage.textContent = 'Enter your master password to view your budget.';
    setPasswordSection.classList.add('hidden');
    loginSection.classList.remove('hidden');
  }
}

setPasswordBtn.addEventListener('click', async () => {
  const p1 = newPasswordInput.value.trim();
  const p2 = newPasswordConfirmInput.value.trim();
  if (!p1 || !p2) { alert('Enter and confirm password.'); return; }
  if (p1 !== p2) { alert('Passwords do not match.'); return; }
  const hash = await sha256(p1);
  localStorage.setItem(PASS_KEY_V3, hash);
  newPasswordInput.value = '';
  newPasswordConfirmInput.value = '';
  unlockApp();
});

loginBtn.addEventListener('click', async () => {
  const p = loginPasswordInput.value.trim();
  if (!p) return;
  const hash = await sha256(p);
  const stored = localStorage.getItem(PASS_KEY_V3);
  if (hash === stored) {
    loginPasswordInput.value = '';
    unlockApp();
  } else {
    alert('Incorrect password.');
  }
});

function unlockApp() {
  authScreen.classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  loadState();
  initTabs();
  initForms();
  renderAll();
}

// ---------- Tabs ----------
const tabButtons = document.querySelectorAll('.tab-btn');
function initTabs() {
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');
      tabButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('main section').forEach(sec => {
        sec.classList.toggle('hidden', sec.id !== tabId);
      });
    });
  });
}

// ---------- Elements ----------
const accountNameInput = document.getElementById('accountNameInput');
const accountTypeInput = document.getElementById('accountTypeInput');
const accountBalanceInput = document.getElementById('accountBalanceInput');
const addAccountBtn = document.getElementById('addAccountBtn');
const accountsTableBody = document.getElementById('accountsTableBody');

const txDateInput = document.getElementById('txDateInput');
const txDescriptionInput = document.getElementById('txDescriptionInput');
const txCategoryInput = document.getElementById('txCategoryInput');
const txAccountInput = document.getElementById('txAccountInput');
const txAmountInput = document.getElementById('txAmountInput');
const txIsPlannedInput = document.getElementById('txIsPlannedInput');
const txRecurrenceInput = document.getElementById('txRecurrenceInput');
const addTxBtn = document.getElementById('addTxBtn');
const recentTxTableBody = document.getElementById('recentTxTableBody');

const totalCashLine = document.getElementById('totalCashLine');
const accountBalances = document.getElementById('accountBalances');
const monthSummary = document.getElementById('monthSummary');
const categorySummary = document.getElementById('categorySummary');
const riskSummary = document.getElementById('riskSummary');
const alertContainer = document.getElementById('alertContainer');
const forecastSummary = document.getElementById('forecastSummary');

const categoriesList = document.getElementById('categoriesList');
const trendChartV3 = document.getElementById('trendChartV3');

const forecastDaysInput = document.getElementById('forecastDaysInput');
const warningBufferInput = document.getElementById('warningBufferInput');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const resetPasswordBtn = document.getElementById('resetPasswordBtn');

// ---------- Forms ----------
function initForms() {
  addAccountBtn.addEventListener('click', () => {
    const name = accountNameInput.value.trim();
    const type = accountTypeInput.value;
    const balance = parseFloat(accountBalanceInput.value || '0') || 0;
    if (!name) { alert('Account name required.'); return; }
    const existing = state.accounts.find(a => a.name === name);
    if (existing) {
      existing.type = type;
      existing.balance = balance;
    } else {
      state.accounts.push({
        id: 'acct_' + Date.now() + '_' + Math.random().toString(16).slice(2),
        name,
        type,
        balance
      });
    }
    saveState();
    accountNameInput.value = '';
    accountBalanceInput.value = '';
    renderAll();
  });

  addTxBtn.addEventListener('click', () => {
    const dateVal = txDateInput.value;
    const desc = txDescriptionInput.value.trim();
    const cat = txCategoryInput.value.trim() || 'Uncategorized';
    const acctId = txAccountInput.value;
    const amount = parseFloat(txAmountInput.value || '0');
    const isPlanned = txIsPlannedInput.checked;
    const recurrence = txRecurrenceInput.value || 'none';

    if (!dateVal || !acctId || !amount) {
      alert('Date, account, and non-zero amount required.');
      return;
    }

    state.transactions.push({
      id: 'tx_' + Date.now() + '_' + Math.random().toString(16).slice(2),
      dateISO: dateVal,
      description: desc || '(no description)',
      category: cat,
      accountId: acctId,
      amount,
      isPlanned,
      recurrence
    });

    saveState();
    txDescriptionInput.value = '';
    txAmountInput.value = '';
    txIsPlannedInput.checked = false;
    txRecurrenceInput.value = 'none';
    renderAll();
  });

  saveSettingsBtn.addEventListener('click', () => {
    const days = parseInt(forecastDaysInput.value || '90', 10);
    const buf = parseFloat(warningBufferInput.value || '0');
    state.settings.forecastDays = isNaN(days) ? 90 : days;
    state.settings.warningBuffer = isNaN(buf) ? 0 : buf;
    saveState();
    renderAll();
  });

  resetPasswordBtn.addEventListener('click', () => {
    if (confirm('Reset password? Data stays on this device.')) {
      localStorage.removeItem(PASS_KEY_V3);
      location.reload();
    }
  });
}

// ---------- Helpers ----------
function getTodayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function isSameMonth(dateISO, todayISO) {
  return dateISO.slice(0,7) === todayISO.slice(0,7);
}
function toDate(iso) {
  return new Date(iso + 'T00:00:00');
}
function addDays(iso, n) {
  const d = toDate(iso);
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0,10);
}

// Generate recurring instances for forecast horizon
function generateRecurringInstances(tx, startISO, days) {
  const out = [];
  if (!tx.recurrence || tx.recurrence === 'none') return out;

  const txDate = tx.dateISO;
  const horizonEnd = addDays(startISO, days);

  let step = 0;
  if (tx.recurrence === 'weekly') step = 7;
  else if (tx.recurrence === 'biweekly') step = 14;
  else if (tx.recurrence === 'monthly') step = 30;

  if (!step) return out;

  let currentISO = txDate;
  while (currentISO <= horizonEnd) {
    if (currentISO > startISO) {
      out.push({
        ...tx,
        dateISO: currentISO
      });
    }
    currentISO = addDays(currentISO, step);
  }
  return out;
}

function computeBalancesAndForecastWithRecurrence() {
  const todayISO = getTodayISO();
  const todayDate = toDate(todayISO);
  const days = state.settings.forecastDays || 90;

  const perAccountBalance = {};
  state.accounts.forEach(a => perAccountBalance[a.id] = a.balance || 0);

  let txs = [...state.transactions];

  const recurringClones = [];
  for (const tx of state.transactions) {
    const clones = generateRecurringInstances(tx, todayISO, days);
    recurringClones.push(...clones);
  }
  txs = txs.concat(recurringClones);

  const txsSorted = txs.sort((a,b)=>a.dateISO.localeCompare(b.dateISO));

  for (const tx of txsSorted) {
    if (tx.dateISO <= todayISO) {
      if (perAccountBalance[tx.accountId] != null) {
        perAccountBalance[tx.accountId] += tx.amount;
      }
    }
  }

  const forecast = [];
  let currentTotal = Object.values(perAccountBalance).reduce((s,v)=>s+v, 0);

  for (let i = 0; i < days; i++) {
    const d = new Date(todayDate);
    d.setDate(d.getDate() + i + 1);
    const iso = d.toISOString().slice(0,10);
    const todaysTxs = txsSorted.filter(tx => tx.dateISO === iso);
    const delta = todaysTxs.reduce((s,tx)=>s+tx.amount, 0);
    currentTotal += delta;
    forecast.push({ dateISO: iso, total: currentTotal, delta });
  }
  return { perAccountBalance, forecast };
}

function computeMonthSummary() {
  const todayISO = getTodayISO();
  let income = 0, expenses = 0;
  const perCategory = {};
  for (const tx of state.transactions) {
    if (!isSameMonth(tx.dateISO, todayISO)) continue;
    if (tx.amount >= 0) income += tx.amount;
    else expenses += tx.amount;
    if (!perCategory[tx.category]) perCategory[tx.category] = 0;
    perCategory[tx.category] += tx.amount;
  }
  return { income, expenses, perCategory };
}

function groupByMonthNet() {
  const agg = {};
  for (const tx of state.transactions) {
    const ym = tx.dateISO.slice(0,7);
    if (!agg[ym]) agg[ym] = 0;
    agg[ym] += tx.amount;
  }
  return Object.entries(agg).sort((a,b)=>a[0].localeCompare(b[0]));
}

// ---------- Chart ----------
function drawTrendChart() {
  if (!trendChartV3) return;
  const ctx = trendChartV3.getContext('2d');
  const entries = groupByMonthNet();
  ctx.clearRect(0,0,trendChartV3.width,trendChartV3.height);
  if (!entries.length) return;
  const labels = entries.map(e=>e[0]);
  const values = entries.map(e=>e[1]);
  const w = trendChartV3.width;
  const h = trendChartV3.height;
  const padding = 30;
  const minVal = Math.min(...values, 0);
  const maxVal = Math.max(...values, 0);
  const span = maxVal - minVal || 1;

  ctx.beginPath();
  ctx.moveTo(padding,padding);
  ctx.lineTo(padding,h-padding);
  ctx.lineTo(w-padding,h-padding);
  ctx.stroke();

  const yZero = h-padding - (0 - minVal)/span*(h-2*padding);
  ctx.beginPath();
  ctx.moveTo(padding,yZero);
  ctx.lineTo(w-padding,yZero);
  ctx.setLineDash([4,2]);
  ctx.stroke();
  ctx.setLineDash([]);

  const stepX = (w-2*padding)/Math.max(labels.length-1,1);
  ctx.beginPath();
  values.forEach((v,idx)=>{
    const x = padding + stepX*idx;
    const y = h-padding - (v-minVal)/span*(h-2*padding);
    if (idx===0) ctx.moveTo(x,y);
    else ctx.lineTo(x,y);
  });
  ctx.stroke();

  ctx.font = '10px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  labels.forEach((lab,idx)=>{
    const x = padding + stepX*idx;
    ctx.fillText(lab,x,h-padding+4);
  });
}

// ---------- Risk analysis ----------
function analyzeRisk(forecast) {
  const buffer = state.settings.warningBuffer || 0;
  let belowBufferSpans = [];
  let belowZeroSpans = [];

  let currentSpan = null;
  let currentZeroSpan = null;

  forecast.forEach((day, idx) => {
    if (day.total < buffer) {
      if (!currentSpan) currentSpan = { start: day.dateISO, end: day.dateISO, length: 1 };
      else { currentSpan.end = day.dateISO; currentSpan.length++; }
    } else if (currentSpan) {
      belowBufferSpans.push(currentSpan);
      currentSpan = null;
    }

    if (day.total < 0) {
      if (!currentZeroSpan) currentZeroSpan = { start: day.dateISO, end: day.dateISO, length: 1 };
      else { currentZeroSpan.end = day.dateISO; currentZeroSpan.length++; }
    } else if (currentZeroSpan) {
      belowZeroSpans.push(currentZeroSpan);
      currentZeroSpan = null;
    }
  });

  if (currentSpan) belowBufferSpans.push(currentSpan);
  if (currentZeroSpan) belowZeroSpans.push(currentZeroSpan);

  const anyNegative = belowZeroSpans.length > 0;
  const anyBelowBuffer = belowBufferSpans.length > 0;

  let level = 'Stable';
  if (anyNegative) level = 'Danger';
  else if (anyBelowBuffer) level = 'Tight';

  return { level, belowBufferSpans, belowZeroSpans };
}

// ---------- Render ----------
function renderOverview() {
  const { perAccountBalance, forecast } = computeBalancesAndForecastWithRecurrence();
  const totalCash = Object.values(perAccountBalance).reduce((s,v)=>s+v,0);
  totalCashLine.textContent = `Total cash: ${totalCash.toFixed(2)}`;

  accountBalances.innerHTML = '';
  state.accounts.forEach(a => {
    const li = document.createElement('li');
    const bal = perAccountBalance[a.id] || 0;
    const sign = bal < 0 ? '-' : '';
    li.textContent = `${a.name}: ${sign}${Math.abs(bal).toFixed(2)}`;
    accountBalances.appendChild(li);
  });

  const { income, expenses, perCategory } = computeMonthSummary();
  const net = income + expenses;
  monthSummary.textContent = `Income: ${income.toFixed(2)} | Expenses: ${Math.abs(expenses).toFixed(2)} | Net: ${net.toFixed(2)}`;

  categorySummary.innerHTML = '';
  const catsSorted = Object.entries(perCategory)
    .sort((a,b)=>Math.abs(b[1]) - Math.abs(a[1]))
    .slice(0,5);
  if (catsSorted.length) {
    const div = document.createElement('div');
    div.className = 'pill-row';
    catsSorted.forEach(([cat,val])=>{
      const span = document.createElement('span');
      span.className = 'pill';
      span.textContent = `${cat}: ${val.toFixed(2)}`;
      div.appendChild(span);
    });
    categorySummary.appendChild(div);
  } else {
    categorySummary.textContent = 'No transactions this month yet.';
  }

  riskSummary.innerHTML = '';
  const risk = analyzeRisk(forecast);
  const riskDiv = document.createElement('div');
  riskDiv.className = 'alert';
  if (risk.level === 'Danger') {
    riskDiv.classList.add('danger');
    riskDiv.textContent = `🔴 Risk level: DANGER – forecast includes days with negative cash.`;
  } else if (risk.level === 'Tight') {
    riskDiv.classList.add('warning');
    riskDiv.textContent = `🟠 Risk level: TIGHT – forecast drops below your buffer without going negative.`;
  } else {
    riskDiv.classList.add('ok');
    riskDiv.textContent = `🟢 Risk level: STABLE – forecast stays above your buffer.`;
  }
  riskSummary.appendChild(riskDiv);

  if (risk.belowZeroSpans.length) {
    const span = risk.belowZeroSpans[0];
    const p = document.createElement('p');
    p.style.fontSize = '0.85rem';
    p.textContent = `Negative cash from ${span.start} to ${span.end} (${span.length} day(s)).`;
    riskSummary.appendChild(p);
  } else if (risk.belowBufferSpans.length) {
    const span = risk.belowBufferSpans[0];
    const p = document.createElement('p');
    p.style.fontSize = '0.85rem';
    p.textContent = `Below buffer from ${span.start} to ${span.end} (${span.length} day(s)).`;
    riskSummary.appendChild(p);
  }

  alertContainer.innerHTML = '';
  const buffer = state.settings.warningBuffer || 0;
  let minTotal = totalCash;
  let minDay = null;
  for (const d of forecast) {
    if (d.total < minTotal) {
      minTotal = d.total;
      minDay = d;
    }
  }
  if (minDay) {
    let msg = '';
    let cls = 'alert ok';
    if (minTotal < 0) {
      msg = `⚠️ ALERT: Forecast goes negative (${minTotal.toFixed(2)}) on ${minDay.dateISO}.`;
      cls = 'alert danger';
    } else if (minTotal < buffer) {
      msg = `⚠️ Warning: Lowest forecasted cash is ${minTotal.toFixed(2)} on ${minDay.dateISO} (buffer: ${buffer.toFixed(2)}).`;
      cls = 'alert warning';
    } else {
      msg = `✅ Forecast looks okay. Lowest cash in next ${state.settings.forecastDays} days is ${minTotal.toFixed(2)}.`;
    }
    const div = document.createElement('div');
    div.className = cls;
    div.textContent = msg;
    alertContainer.appendChild(div);
  }

  if (forecast.length) {
    const first = forecast[0];
    const last = forecast[forecast.length - 1];
    forecastSummary.textContent = `Tomorrow: ${first.total.toFixed(2)} | ${state.settings.forecastDays} days out: ${last.total.toFixed(2)}.`;
  } else {
    forecastSummary.textContent = 'No forecast data.';
  }

  drawTrendChart();
}

function renderAccounts() {
  accountsTableBody.innerHTML = '';
  state.accounts.forEach(a => {
    const tr = document.createElement('tr');
    const tdName = document.createElement('td');
    const tdType = document.createElement('td');
    const tdBal = document.createElement('td');
    const tdActions = document.createElement('td');

    tdName.textContent = a.name;
    tdType.textContent = a.type;
    tdBal.textContent = a.balance.toFixed(2);
    tdBal.className = 'text-right';

    const delBtn = document.createElement('button');
    delBtn.textContent = '✕';
    delBtn.className = 'secondary';
    delBtn.style.fontSize = '0.75rem';
    delBtn.addEventListener('click', () => {
      if (confirm(`Delete account "${a.name}"?`)) {
        state.accounts = state.accounts.filter(x => x.id !== a.id);
        saveState();
        renderAll();
      }
    });
    tdActions.appendChild(delBtn);

    tr.appendChild(tdName);
    tr.appendChild(tdType);
    tr.appendChild(tdBal);
    tr.appendChild(tdActions);
    accountsTableBody.appendChild(tr);
  });

  txAccountInput.innerHTML = '';
  state.accounts.forEach(a => {
    const opt = document.createElement('option');
    opt.value = a.id;
    opt.textContent = a.name;
    txAccountInput.appendChild(opt);
  });
}

function renderTransactions() {
  const sorted = [...state.transactions]
    .sort((a,b)=>b.dateISO.localeCompare(a.dateISO))
    .slice(0,30);
  recentTxTableBody.innerHTML = '';
  sorted.forEach(tx => {
    const tr = document.createElement('tr');
    const tdDate = document.createElement('td');
    const tdDesc = document.createElement('td');
    const tdAcct = document.createElement('td');
    const tdAmount = document.createElement('td');
    const tdRec = document.createElement('td');

    const acct = state.accounts.find(a => a.id === tx.accountId);
    tdDate.textContent = tx.dateISO;
    tdDesc.textContent = tx.description;
    tdAcct.textContent = acct ? acct.name : '?';
    tdAmount.textContent = tx.amount.toFixed(2);
    tdAmount.className = 'text-right';
    tdRec.textContent = tx.recurrence || 'none';

    tr.appendChild(tdDate);
    tr.appendChild(tdDesc);
    tr.appendChild(tdAcct);
    tr.appendChild(tdAmount);
    tr.appendChild(tdRec);

    recentTxTableBody.appendChild(tr);
  });
}

function renderCategories() {
  const todayISO = getTodayISO();
  const agg = {};
  for (const tx of state.transactions) {
    if (!isSameMonth(tx.dateISO, todayISO)) continue;
    if (!agg[tx.category]) agg[tx.category] = { spent: 0, income: 0 };
    if (tx.amount < 0) agg[tx.category].spent += tx.amount;
    else agg[tx.category].income += tx.amount;
  }
  const entries = Object.entries(agg)
    .sort((a,b)=>Math.abs(b[1].spent) - Math.abs(a[1].spent));

  categoriesList.innerHTML = '';
  if (!entries.length) {
    categoriesList.textContent = 'No data for this month.';
    return;
  }
  entries.forEach(([cat,vals])=>{
    const card = document.createElement('div');
    card.className = 'card';
    card.style.margin = '0 0 0.5rem';
    const spent = Math.abs(vals.spent);
    const income = vals.income;
    const net = vals.income + vals.spent;
    card.innerHTML = `
      <strong>${cat}</strong><br>
      Spent: ${spent.toFixed(2)} |
      Income: ${income.toFixed(2)} |
      Net: ${net.toFixed(2)}
    `;
    categoriesList.appendChild(card);
  });
}

function renderSettings() {
  forecastDaysInput.value = state.settings.forecastDays;
  warningBufferInput.value = state.settings.warningBuffer;
}

function renderAll() {
  renderAccounts();
  renderTransactions();
  renderOverview();
  renderCategories();
  renderSettings();
}

// ---------- Boot ----------
window.addEventListener('DOMContentLoaded', () => {
  initAuth();
});
