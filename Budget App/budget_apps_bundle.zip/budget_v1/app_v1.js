// app_v1.js – core cash-flow & alerts

const STORAGE_KEY_V1 = 'budgetV1_state';
const PASS_KEY_V1 = 'budgetV1_masterHash';

let state = {
  accounts: [],        // {id, name, type, balance}
  transactions: [],    // {id, dateISO, description, category, accountId, amount, isPlanned}
  settings: {
    forecastDays: 30,
    warningBuffer: 500
  }
};

// ---------- SHA-256 helper ----------
async function sha256(text) {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ---------- Persistence ----------
function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY_V1);
  if (!raw) return;
  try {
    const parsed = JSON.parse(raw);
    state = Object.assign(state, parsed);
  } catch (e) {
    console.error('Failed to parse state', e);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY_V1, JSON.stringify(state));
}

// ---------- Auth ----------
const authScreen = document.getElementById('authScreen');
const authTitle = document.getElementById('authTitle');
const authMessage = document.getElementById('authMessage');
const setPasswordSection = document.getElementById('setPasswordSection');
const loginSection = document.getElementById('loginSection');
const newPasswordInput = document.getElementById('newPassword');
const newPasswordConfirmInput = document.getElementById('newPasswordConfirm');
const setPasswordBtn = document.getElementById('setPasswordBtn');
const loginPasswordInput = document.getElementById('loginPassword');
const loginBtn = document.getElementById('loginBtn');

async function initAuth() {
  const hash = localStorage.getItem(PASS_KEY_V1);
  if (!hash) {
    authTitle.textContent = 'Set Master Password';
    authMessage.textContent = 'Choose a password to lock your budget on this device.';
    setPasswordSection.classList.remove('hidden');
    loginSection.classList.add('hidden');
  } else {
    authTitle.textContent = 'Locked';
    authMessage.textContent = 'Enter your master password to view your budget.';
    setPasswordSection.classList.add('hidden');
    loginSection.classList.remove('hidden');
  }
}

setPasswordBtn.addEventListener('click', async () => {
  const p1 = newPasswordInput.value.trim();
  const p2 = newPasswordConfirmInput.value.trim();
  if (!p1 || !p2) {
    alert('Please enter and confirm a password.');
    return;
  }
  if (p1 !== p2) {
    alert('Passwords do not match.');
    return;
  }
  const hash = await sha256(p1);
  localStorage.setItem(PASS_KEY_V1, hash);
  newPasswordInput.value = '';
  newPasswordConfirmInput.value = '';
  unlockApp();
});

loginBtn.addEventListener('click', async () => {
  const p = loginPasswordInput.value.trim();
  if (!p) return;
  const hash = await sha256(p);
  const stored = localStorage.getItem(PASS_KEY_V1);
  if (hash === stored) {
    loginPasswordInput.value = '';
    unlockApp();
  } else {
    alert('Incorrect password.');
  }
});

function unlockApp() {
  authScreen.classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  loadState();
  initTabs();
  initForms();
  renderAll();
}

// ---------- Tabs ----------
const tabButtons = document.querySelectorAll('.tab-btn');

function initTabs() {
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');
      tabButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('main section').forEach(sec => {
        sec.classList.toggle('hidden', sec.id !== tabId);
      });
    });
  });
}

// ---------- Elements ----------
const accountNameInput = document.getElementById('accountNameInput');
const accountTypeInput = document.getElementById('accountTypeInput');
const accountBalanceInput = document.getElementById('accountBalanceInput');
const addAccountBtn = document.getElementById('addAccountBtn');
const accountsTableBody = document.getElementById('accountsTableBody');

const txDateInput = document.getElementById('txDateInput');
const txDescriptionInput = document.getElementById('txDescriptionInput');
const txCategoryInput = document.getElementById('txCategoryInput');
const txAccountInput = document.getElementById('txAccountInput');
const txAmountInput = document.getElementById('txAmountInput');
const txIsPlannedInput = document.getElementById('txIsPlannedInput');
const addTxBtn = document.getElementById('addTxBtn');
const recentTxTableBody = document.getElementById('recentTxTableBody');

const totalCashLine = document.getElementById('totalCashLine');
const accountBalances = document.getElementById('accountBalances');
const monthSummary = document.getElementById('monthSummary');
const categorySummary = document.getElementById('categorySummary');
const alertContainer = document.getElementById('alertContainer');
const forecastSummary = document.getElementById('forecastSummary');

const categoriesList = document.getElementById('categoriesList');

const forecastDaysInput = document.getElementById('forecastDaysInput');
const warningBufferInput = document.getElementById('warningBufferInput');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const resetPasswordBtn = document.getElementById('resetPasswordBtn');

// ---------- Form init ----------
function initForms() {
  // Accounts
  addAccountBtn.addEventListener('click', () => {
    const name = accountNameInput.value.trim();
    const type = accountTypeInput.value;
    const balance = parseFloat(accountBalanceInput.value || '0') || 0;
    if (!name) {
      alert('Account name required.');
      return;
    }
    const existing = state.accounts.find(a => a.name === name);
    if (existing) {
      existing.type = type;
      existing.balance = balance;
    } else {
      state.accounts.push({
        id: 'acct_' + Date.now() + '_' + Math.random().toString(16).slice(2),
        name,
        type,
        balance
      });
    }
    saveState();
    accountNameInput.value = '';
    accountBalanceInput.value = '';
    renderAll();
  });

  // Transactions
  addTxBtn.addEventListener('click', () => {
    const dateVal = txDateInput.value;
    const desc = txDescriptionInput.value.trim();
    const cat = txCategoryInput.value.trim() || 'Uncategorized';
    const acctId = txAccountInput.value;
    const amount = parseFloat(txAmountInput.value || '0');
    const isPlanned = txIsPlannedInput.checked;

    if (!dateVal || !acctId || !amount) {
      alert('Date, account, and non-zero amount required.');
      return;
    }

    state.transactions.push({
      id: 'tx_' + Date.now() + '_' + Math.random().toString(16).slice(2),
      dateISO: dateVal,
      description: desc || '(no description)',
      category: cat,
      accountId: acctId,
      amount: amount,
      isPlanned: !!isPlanned
    });

    saveState();
    txDescriptionInput.value = '';
    txAmountInput.value = '';
    txIsPlannedInput.checked = false;
    renderAll();
  });

  // Settings
  saveSettingsBtn.addEventListener('click', () => {
    const days = parseInt(forecastDaysInput.value || '30', 10);
    const buf = parseFloat(warningBufferInput.value || '0');
    state.settings.forecastDays = isNaN(days) ? 30 : days;
    state.settings.warningBuffer = isNaN(buf) ? 0 : buf;
    saveState();
    renderAll();
  });

  resetPasswordBtn.addEventListener('click', () => {
    if (confirm('Reset password? Your data will stay on this device.')) {
      localStorage.removeItem(PASS_KEY_V1);
      location.reload();
    }
  });
}

// ---------- Helpers ----------
function getTodayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function isSameMonth(dateISO, todayISO) {
  return dateISO.slice(0, 7) === todayISO.slice(0, 7);
}

function computeBalancesAndForecast() {
  const todayISO = getTodayISO();
  const todayDate = new Date(todayISO);
  const days = state.settings.forecastDays || 30;

  const perAccountBalance = {};
  state.accounts.forEach(a => perAccountBalance[a.id] = a.balance || 0);

  const txsSorted = [...state.transactions].sort((a, b) => a.dateISO.localeCompare(b.dateISO));

  // apply all tx up to today
  for (const tx of txsSorted) {
    if (tx.dateISO <= todayISO) {
      if (perAccountBalance[tx.accountId] != null) {
        perAccountBalance[tx.accountId] += tx.amount;
      }
    }
  }

  const forecast = [];
  let currentTotal = Object.values(perAccountBalance).reduce((s,v) => s+v, 0);
  const futureTxs = txsSorted.filter(tx => tx.dateISO > todayISO);

  for (let i = 0; i < days; i++) {
    const d = new Date(todayDate);
    d.setDate(d.getDate() + i + 1);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const iso = `${y}-${m}-${day}`;

    const todaysTxs = futureTxs.filter(tx => tx.dateISO === iso);
    const delta = todaysTxs.reduce((s, tx) => s + tx.amount, 0);
    currentTotal += delta;
    forecast.push({ dateISO: iso, total: currentTotal, delta });
  }

  return { perAccountBalance, forecast };
}

function computeMonthSummary() {
  const todayISO = getTodayISO();
  let income = 0;
  let expenses = 0;
  const perCategory = {};

  for (const tx of state.transactions) {
    if (isSameMonth(tx.dateISO, todayISO)) {
      if (tx.amount >= 0) income += tx.amount;
      else expenses += tx.amount;

      if (!perCategory[tx.category]) perCategory[tx.category] = 0;
      perCategory[tx.category] += tx.amount;
    }
  }
  return { income, expenses, perCategory };
}

// ---------- Render ----------
function renderOverview() {
  const { perAccountBalance, forecast } = computeBalancesAndForecast();
  const totalCash = Object.values(perAccountBalance).reduce((s,v) => s+v, 0);
  totalCashLine.textContent = `Total cash: ${totalCash.toFixed(2)}`;

  accountBalances.innerHTML = '';
  state.accounts.forEach(a => {
    const li = document.createElement('li');
    const bal = perAccountBalance[a.id] || 0;
    const sign = bal < 0 ? '-' : '';
    li.textContent = `${a.name}: ${sign}${Math.abs(bal).toFixed(2)}`;
    accountBalances.appendChild(li);
  });

  const { income, expenses, perCategory } = computeMonthSummary();
  const net = income + expenses; // expenses is negative

  monthSummary.textContent = `Income: ${income.toFixed(2)} | Expenses: ${Math.abs(expenses).toFixed(2)} | Net: ${net.toFixed(2)}`;

  categorySummary.innerHTML = '';
  const catsSorted = Object.entries(perCategory)
    .sort((a,b) => Math.abs(b[1]) - Math.abs(a[1]))
    .slice(0,5);

  if (catsSorted.length) {
    const div = document.createElement('div');
    div.className = 'pill-row';
    catsSorted.forEach(([cat,val]) => {
      const span = document.createElement('span');
      span.className = 'pill';
      span.textContent = `${cat}: ${val.toFixed(2)}`;
      div.appendChild(span);
    });
    categorySummary.appendChild(div);
  } else {
    categorySummary.textContent = 'No transactions this month yet.';
  }

  alertContainer.innerHTML = '';
  const buffer = state.settings.warningBuffer || 0;
  let minTotal = totalCash;
  let minDay = null;

  for (const day of forecast) {
    if (day.total < minTotal) {
      minTotal = day.total;
      minDay = day;
    }
  }

  if (minDay) {
    let msg = '';
    let className = 'alert ok';
    if (minTotal < 0) {
      msg = `⚠️ ALERT: Forecast shows negative cash (${minTotal.toFixed(2)}) on ${minDay.dateISO}.`;
      className = 'alert danger';
    } else if (minTotal < buffer) {
      msg = `⚠️ Warning: Lowest forecasted cash is ${minTotal.toFixed(2)} on ${minDay.dateISO} (buffer: ${buffer.toFixed(2)}).`;
      className = 'alert warning';
    } else {
      msg = `✅ Forecast looks okay. Lowest cash in next ${state.settings.forecastDays} days is ${minTotal.toFixed(2)} on ${minDay.dateISO}.`;
    }
    const div = document.createElement('div');
    div.className = className;
    div.textContent = msg;
    alertContainer.appendChild(div);
  } else {
    forecastSummary.textContent = 'No future transactions entered yet.';
  }

  if (forecast.length) {
    const first = forecast[0];
    const last = forecast[forecast.length - 1];
    forecastSummary.textContent =
      `Tomorrow: ${first.total.toFixed(2)} | ` +
      `${state.settings.forecastDays} days out: ${last.total.toFixed(2)}.`;
  }
}

function renderAccounts() {
  accountsTableBody.innerHTML = '';
  state.accounts.forEach(a => {
    const tr = document.createElement('tr');
    const tdName = document.createElement('td');
    const tdType = document.createElement('td');
    const tdBal = document.createElement('td');
    const tdActions = document.createElement('td');

    tdName.textContent = a.name;
    tdType.textContent = a.type;
    tdBal.textContent = a.balance.toFixed(2);
    tdBal.className = 'text-right';

    const delBtn = document.createElement('button');
    delBtn.textContent = '✕';
    delBtn.className = 'secondary';
    delBtn.style.fontSize = '0.75rem';
    delBtn.addEventListener('click', () => {
      if (confirm(`Delete account "${a.name}"? Transactions stay in history.`)) {
        state.accounts = state.accounts.filter(x => x.id !== a.id);
        saveState();
        renderAll();
      }
    });
    tdActions.appendChild(delBtn);

    tr.appendChild(tdName);
    tr.appendChild(tdType);
    tr.appendChild(tdBal);
    tr.appendChild(tdActions);
    accountsTableBody.appendChild(tr);
  });

  // tx account dropdown
  txAccountInput.innerHTML = '';
  state.accounts.forEach(a => {
    const opt = document.createElement('option');
    opt.value = a.id;
    opt.textContent = a.name;
    txAccountInput.appendChild(opt);
  });
}

function renderTransactions() {
  const sorted = [...state.transactions]
    .sort((a,b) => b.dateISO.localeCompare(a.dateISO))
    .slice(0, 20);
  recentTxTableBody.innerHTML = '';
  sorted.forEach(tx => {
    const tr = document.createElement('tr');
    const tdDate = document.createElement('td');
    const tdDesc = document.createElement('td');
    const tdAcct = document.createElement('td');
    const tdAmount = document.createElement('td');

    const acct = state.accounts.find(a => a.id === tx.accountId);
    tdDate.textContent = tx.dateISO;
    tdDesc.textContent = tx.description;
    tdAcct.textContent = acct ? acct.name : '?';
    tdAmount.textContent = tx.amount.toFixed(2);
    tdAmount.className = 'text-right';

    tr.appendChild(tdDate);
    tr.appendChild(tdDesc);
    tr.appendChild(tdAcct);
    tr.appendChild(tdAmount);
    recentTxTableBody.appendChild(tr);
  });
}

function renderCategories() {
  const todayISO = getTodayISO();
  const catAgg = {};
  for (const tx of state.transactions) {
    if (!isSameMonth(tx.dateISO, todayISO)) continue;
    if (!catAgg[tx.category]) catAgg[tx.category] = { spent: 0, income: 0 };
    if (tx.amount < 0) catAgg[tx.category].spent += tx.amount;
    else catAgg[tx.category].income += tx.amount;
  }
  const entries = Object.entries(catAgg)
    .sort((a,b) => Math.abs(b[1].spent) - Math.abs(a[1].spent));

  categoriesList.innerHTML = '';
  if (!entries.length) {
    categoriesList.textContent = 'No data for this month.';
    return;
  }
  entries.forEach(([cat, agg]) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.style.margin = '0 0 0.5rem';
    const total = agg.income + agg.spent;
    card.innerHTML = `
      <strong>${cat}</strong><br>
      Spent: ${Math.abs(agg.spent).toFixed(2)} |
      Income: ${agg.income.toFixed(2)} |
      Net: ${total.toFixed(2)}
    `;
    categoriesList.appendChild(card);
  });
}

function renderSettings() {
  forecastDaysInput.value = state.settings.forecastDays;
  warningBufferInput.value = state.settings.warningBuffer;
}

function renderAll() {
  renderAccounts();
  renderTransactions();
  renderOverview();
  renderCategories();
  renderSettings();
}

// ---------- Boot ----------
window.addEventListener('DOMContentLoaded', () => {
  initAuth();
});
