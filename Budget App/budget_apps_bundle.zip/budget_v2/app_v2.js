// app_v2.js – budgets + trend chart

const STORAGE_KEY_V2 = 'budgetV2_state';
const PASS_KEY_V2 = 'budgetV2_masterHash';

let state = {
  accounts: [],
  transactions: [],
  settings: {
    forecastDays: 60,
    warningBuffer: 500
  },
  categoryBudgets: {} // {category: monthlyBudget}
};

// ---------- SHA-256 ----------
async function sha256(text) {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ---------- Persistence ----------
function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY_V2);
  if (!raw) return;
  try {
    const parsed = JSON.parse(raw);
    state = Object.assign(state, parsed);
  } catch (e) {
    console.error('Failed to parse V2 state', e);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(state));
}

// ---------- Auth ----------
const authScreen = document.getElementById('authScreen');
const authTitle = document.getElementById('authTitle');
const authMessage = document.getElementById('authMessage');
const setPasswordSection = document.getElementById('setPasswordSection');
const loginSection = document.getElementById('loginSection');
const newPasswordInput = document.getElementById('newPassword');
const newPasswordConfirmInput = document.getElementById('newPasswordConfirm');
const setPasswordBtn = document.getElementById('setPasswordBtn');
const loginPasswordInput = document.getElementById('loginPassword');
const loginBtn = document.getElementById('loginBtn');

async function initAuth() {
  const hash = localStorage.getItem(PASS_KEY_V2);
  if (!hash) {
    authTitle.textContent = 'Set Master Password';
    authMessage.textContent = 'Choose a password to lock your budget on this device.';
    setPasswordSection.classList.remove('hidden');
    loginSection.classList.add('hidden');
  } else {
    authTitle.textContent = 'Locked';
    authMessage.textContent = 'Enter your master password to view your budget.';
    setPasswordSection.classList.add('hidden');
    loginSection.classList.remove('hidden');
  }
}

setPasswordBtn.addEventListener('click', async () => {
  const p1 = newPasswordInput.value.trim();
  const p2 = newPasswordConfirmInput.value.trim();
  if (!p1 || !p2) { alert('Enter and confirm password.'); return; }
  if (p1 !== p2) { alert('Passwords do not match.'); return; }
  const hash = await sha256(p1);
  localStorage.setItem(PASS_KEY_V2, hash);
  newPasswordInput.value = '';
  newPasswordConfirmInput.value = '';
  unlockApp();
});

loginBtn.addEventListener('click', async () => {
  const p = loginPasswordInput.value.trim();
  if (!p) return;
  const hash = await sha256(p);
  const stored = localStorage.getItem(PASS_KEY_V2);
  if (hash === stored) {
    loginPasswordInput.value = '';
    unlockApp();
  } else {
    alert('Incorrect password.');
  }
});

function unlockApp() {
  authScreen.classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  loadState();
  initTabs();
  initForms();
  renderAll();
}

// ---------- Tabs ----------
const tabButtons = document.querySelectorAll('.tab-btn');
function initTabs() {
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');
      tabButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('main section').forEach(sec => {
        sec.classList.toggle('hidden', sec.id !== tabId);
      });
    });
  });
}

// ---------- Elements ----------
const accountNameInput = document.getElementById('accountNameInput');
const accountTypeInput = document.getElementById('accountTypeInput');
const accountBalanceInput = document.getElementById('accountBalanceInput');
const addAccountBtn = document.getElementById('addAccountBtn');
const accountsTableBody = document.getElementById('accountsTableBody');

const txDateInput = document.getElementById('txDateInput');
const txDescriptionInput = document.getElementById('txDescriptionInput');
const txCategoryInput = document.getElementById('txCategoryInput');
const txAccountInput = document.getElementById('txAccountInput');
const txAmountInput = document.getElementById('txAmountInput');
const txIsPlannedInput = document.getElementById('txIsPlannedInput');
const addTxBtn = document.getElementById('addTxBtn');
const recentTxTableBody = document.getElementById('recentTxTableBody');

const totalCashLine = document.getElementById('totalCashLine');
const accountBalances = document.getElementById('accountBalances');
const monthSummary = document.getElementById('monthSummary');
const categorySummary = document.getElementById('categorySummary');
const alertContainer = document.getElementById('alertContainer');
const forecastSummary = document.getElementById('forecastSummary');

const categoriesList = document.getElementById('categoriesList');

const forecastDaysInput = document.getElementById('forecastDaysInput');
const warningBufferInput = document.getElementById('warningBufferInput');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const resetPasswordBtn = document.getElementById('resetPasswordBtn');

const budgetCategoryInput = document.getElementById('budgetCategoryInput');
const budgetAmountInput = document.getElementById('budgetAmountInput');
const addBudgetBtn = document.getElementById('addBudgetBtn');
const budgetList = document.getElementById('budgetList');

const trendMetricSelect = document.getElementById('trendMetricSelect');
const trendCategoryLabel = document.getElementById('trendCategoryLabel');
const trendCategoryInput = document.getElementById('trendCategoryInput');
const trendChart = document.getElementById('trendChart');

// ---------- Forms ----------
function initForms() {
  addAccountBtn.addEventListener('click', () => {
    const name = accountNameInput.value.trim();
    const type = accountTypeInput.value;
    const balance = parseFloat(accountBalanceInput.value || '0') || 0;
    if (!name) { alert('Account name required.'); return; }
    const existing = state.accounts.find(a => a.name === name);
    if (existing) {
      existing.type = type;
      existing.balance = balance;
    } else {
      state.accounts.push({
        id: 'acct_' + Date.now() + '_' + Math.random().toString(16).slice(2),
        name,
        type,
        balance
      });
    }
    saveState();
    accountNameInput.value = '';
    accountBalanceInput.value = '';
    renderAll();
  });

  addTxBtn.addEventListener('click', () => {
    const dateVal = txDateInput.value;
    const desc = txDescriptionInput.value.trim();
    const cat = txCategoryInput.value.trim() || 'Uncategorized';
    const acctId = txAccountInput.value;
    const amount = parseFloat(txAmountInput.value || '0');
    const isPlanned = txIsPlannedInput.checked;
    if (!dateVal || !acctId || !amount) {
      alert('Date, account, and non-zero amount required.');
      return;
    }

    state.transactions.push({
      id: 'tx_' + Date.now() + '_' + Math.random().toString(16).slice(2),
      dateISO: dateVal,
      description: desc || '(no description)',
      category: cat,
      accountId: acctId,
      amount,
      isPlanned
    });

    saveState();
    txDescriptionInput.value = '';
    txAmountInput.value = '';
    txIsPlannedInput.checked = false;
    renderAll();
  });

  saveSettingsBtn.addEventListener('click', () => {
    const days = parseInt(forecastDaysInput.value || '60', 10);
    const buf = parseFloat(warningBufferInput.value || '0');
    state.settings.forecastDays = isNaN(days) ? 60 : days;
    state.settings.warningBuffer = isNaN(buf) ? 0 : buf;
    saveState();
    renderAll();
  });

  resetPasswordBtn.addEventListener('click', () => {
    if (confirm('Reset password? Data stays on this device.')) {
      localStorage.removeItem(PASS_KEY_V2);
      location.reload();
    }
  });

  addBudgetBtn.addEventListener('click', () => {
    const cat = budgetCategoryInput.value.trim();
    const amt = parseFloat(budgetAmountInput.value || '0');
    if (!cat || !amt) {
      alert('Category and non-zero budget required.');
      return;
    }
    state.categoryBudgets[cat] = amt;
    saveState();
    budgetCategoryInput.value = '';
    budgetAmountInput.value = '';
    renderBudgets();
    renderCategories(); // update visuals
  });

  trendMetricSelect.addEventListener('change', () => {
    const val = trendMetricSelect.value;
    trendCategoryLabel.classList.toggle('hidden', val !== 'category');
    drawTrendChart();
  });

  trendCategoryInput.addEventListener('input', () => {
    if (trendMetricSelect.value === 'category') drawTrendChart();
  });
}

// ---------- Helpers ----------
function getTodayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function isSameMonth(dateISO, todayISO) {
  return dateISO.slice(0,7) === todayISO.slice(0,7);
}

function computeBalancesAndForecast() {
  const todayISO = getTodayISO();
  const todayDate = new Date(todayISO);
  const days = state.settings.forecastDays || 60;

  const perAccountBalance = {};
  state.accounts.forEach(a => perAccountBalance[a.id] = a.balance || 0);

  const txsSorted = [...state.transactions].sort((a,b) => a.dateISO.localeCompare(b.dateISO));

  for (const tx of txsSorted) {
    if (tx.dateISO <= todayISO) {
      if (perAccountBalance[tx.accountId] != null) {
        perAccountBalance[tx.accountId] += tx.amount;
      }
    }
  }

  const forecast = [];
  let currentTotal = Object.values(perAccountBalance).reduce((s,v)=>s+v, 0);
  const futureTxs = txsSorted.filter(tx => tx.dateISO > todayISO);

  for (let i = 0; i < days; i++) {
    const d = new Date(todayDate);
    d.setDate(d.getDate() + i + 1);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const iso = `${y}-${m}-${day}`;

    const todaysTxs = futureTxs.filter(tx => tx.dateISO === iso);
    const delta = todaysTxs.reduce((s,tx)=>s+tx.amount, 0);
    currentTotal += delta;
    forecast.push({dateISO: iso, total: currentTotal, delta});
  }

  return { perAccountBalance, forecast };
}

function computeMonthSummary() {
  const todayISO = getTodayISO();
  let income = 0, expenses = 0;
  const perCategory = {};
  for (const tx of state.transactions) {
    if (isSameMonth(tx.dateISO, todayISO)) {
      if (tx.amount >= 0) income += tx.amount;
      else expenses += tx.amount;
      if (!perCategory[tx.category]) perCategory[tx.category] = 0;
      perCategory[tx.category] += tx.amount;
    }
  }
  return { income, expenses, perCategory };
}

function groupByMonth(metricFn) {
  const agg = {};
  for (const tx of state.transactions) {
    const ym = tx.dateISO.slice(0,7);
    const val = metricFn(tx);
    if (!val) continue;
    if (!agg[ym]) agg[ym] = 0;
    agg[ym] += val;
  }
  const entries = Object.entries(agg).sort((a,b)=>a[0].localeCompare(b[0]));
  return entries;
}

// ---------- Chart ----------
function drawTrendChart() {
  if (!trendChart) return;
  const ctx = trendChart.getContext('2d');
  const metric = trendMetricSelect.value;
  let entries = [];

  if (metric === 'net') {
    entries = groupByMonth(tx => tx.amount);
  } else if (metric === 'expenses') {
    entries = groupByMonth(tx => tx.amount < 0 ? tx.amount : 0);
  } else if (metric === 'category') {
    const cat = trendCategoryInput.value.trim();
    if (!cat) {
      ctx.clearRect(0,0,trendChart.width,trendChart.height);
      return;
    }
    entries = groupByMonth(tx => tx.category === cat ? tx.amount : 0);
  }

  ctx.clearRect(0,0,trendChart.width,trendChart.height);
  if (!entries.length) return;

  const labels = entries.map(e => e[0]);
  const values = entries.map(e => e[1]);

  const w = trendChart.width;
  const h = trendChart.height;
  const padding = 30;

  const minVal = Math.min(...values, 0);
  const maxVal = Math.max(...values, 0);
  const span = maxVal - minVal || 1;

  ctx.beginPath();
  ctx.moveTo(padding, padding);
  ctx.lineTo(padding, h - padding);
  ctx.lineTo(w - padding, h - padding);
  ctx.stroke();

  const yZero = h - padding - (0 - minVal) / span * (h - 2*padding);
  ctx.beginPath();
  ctx.moveTo(padding, yZero);
  ctx.lineTo(w - padding, yZero);
  ctx.setLineDash([4,2]);
  ctx.stroke();
  ctx.setLineDash([]);

  const stepX = (w - 2*padding) / Math.max(labels.length - 1, 1);
  ctx.beginPath();
  values.forEach((v,idx) => {
    const x = padding + stepX * idx;
    const y = h - padding - (v - minVal) / span * (h - 2*padding);
    if (idx === 0) ctx.moveTo(x,y);
    else ctx.lineTo(x,y);
  });
  ctx.stroke();

  ctx.font = '10px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  labels.forEach((lab, idx) => {
    const x = padding + stepX * idx;
    ctx.fillText(lab, x, h - padding + 4);
  });
}

// ---------- Render ----------
function renderOverview() {
  const { perAccountBalance, forecast } = computeBalancesAndForecast();
  const totalCash = Object.values(perAccountBalance).reduce((s,v)=>s+v,0);
  totalCashLine.textContent = `Total cash: ${totalCash.toFixed(2)}`;

  accountBalances.innerHTML = '';
  state.accounts.forEach(a => {
    const li = document.createElement('li');
    const bal = perAccountBalance[a.id] || 0;
    const sign = bal < 0 ? '-' : '';
    li.textContent = `${a.name}: ${sign}${Math.abs(bal).toFixed(2)}`;
    accountBalances.appendChild(li);
  });

  const { income, expenses, perCategory } = computeMonthSummary();
  const net = income + expenses;
  monthSummary.textContent = `Income: ${income.toFixed(2)} | Expenses: ${Math.abs(expenses).toFixed(2)} | Net: ${net.toFixed(2)}`;

  categorySummary.innerHTML = '';
  const catsSorted = Object.entries(perCategory)
    .sort((a,b)=>Math.abs(b[1]) - Math.abs(a[1]))
    .slice(0,5);
  if (catsSorted.length) {
    const div = document.createElement('div');
    div.className = 'pill-row';
    catsSorted.forEach(([cat,val]) => {
      const span = document.createElement('span');
      span.className = 'pill';
      span.textContent = `${cat}: ${val.toFixed(2)}`;
      div.appendChild(span);
    });
    categorySummary.appendChild(div);
  } else {
    categorySummary.textContent = 'No transactions this month yet.';
  }

  alertContainer.innerHTML = '';
  const buffer = state.settings.warningBuffer || 0;
  let minTotal = totalCash;
  let minDay = null;
  for (const day of forecast) {
    if (day.total < minTotal) {
      minTotal = day.total;
      minDay = day;
    }
  }
  if (minDay) {
    let msg = '';
    let cls = 'alert ok';
    if (minTotal < 0) {
      msg = `⚠️ ALERT: Forecast goes negative (${minTotal.toFixed(2)}) on ${minDay.dateISO}.`;
      cls = 'alert danger';
    } else if (minTotal < buffer) {
      msg = `⚠️ Warning: Lowest forecasted cash is ${minTotal.toFixed(2)} on ${minDay.dateISO} (buffer: ${buffer.toFixed(2)}).`;
      cls = 'alert warning';
    } else {
      msg = `✅ Forecast looks okay. Lowest cash in next ${state.settings.forecastDays} days is ${minTotal.toFixed(2)}.`;
    }
    const div = document.createElement('div');
    div.className = cls;
    div.textContent = msg;
    alertContainer.appendChild(div);
  } else {
    forecastSummary.textContent = 'No future transactions.';
  }

  if (forecast.length) {
    const first = forecast[0];
    const last = forecast[forecast.length - 1];
    forecastSummary.textContent = `Tomorrow: ${first.total.toFixed(2)} | ${state.settings.forecastDays} days out: ${last.total.toFixed(2)}.`;
  }

  drawTrendChart();
}

function renderAccounts() {
  accountsTableBody.innerHTML = '';
  state.accounts.forEach(a => {
    const tr = document.createElement('tr');
    const tdName = document.createElement('td');
    const tdType = document.createElement('td');
    const tdBal = document.createElement('td');
    const tdActions = document.createElement('td');

    tdName.textContent = a.name;
    tdType.textContent = a.type;
    tdBal.textContent = a.balance.toFixed(2);
    tdBal.className = 'text-right';

    const delBtn = document.createElement('button');
    delBtn.textContent = '✕';
    delBtn.className = 'secondary';
    delBtn.style.fontSize = '0.75rem';
    delBtn.addEventListener('click', () => {
      if (confirm(`Delete account "${a.name}"?`)) {
        state.accounts = state.accounts.filter(x => x.id !== a.id);
        saveState();
        renderAll();
      }
    });
    tdActions.appendChild(delBtn);

    tr.appendChild(tdName);
    tr.appendChild(tdType);
    tr.appendChild(tdBal);
    tr.appendChild(tdActions);
    accountsTableBody.appendChild(tr);
  });

  txAccountInput.innerHTML = '';
  state.accounts.forEach(a => {
    const opt = document.createElement('option');
    opt.value = a.id;
    opt.textContent = a.name;
    txAccountInput.appendChild(opt);
  });
}

function renderTransactions() {
  const sorted = [...state.transactions]
    .sort((a,b)=>b.dateISO.localeCompare(a.dateISO))
    .slice(0,20);
  recentTxTableBody.innerHTML = '';
  sorted.forEach(tx => {
    const tr = document.createElement('tr');
    const tdDate = document.createElement('td');
    const tdDesc = document.createElement('td');
    const tdAcct = document.createElement('td');
    const tdAmount = document.createElement('td');

    const acct = state.accounts.find(a => a.id === tx.accountId);
    tdDate.textContent = tx.dateISO;
    tdDesc.textContent = tx.description;
    tdAcct.textContent = acct ? acct.name : '?';
    tdAmount.textContent = tx.amount.toFixed(2);
    tdAmount.className = 'text-right';

    tr.appendChild(tdDate);
    tr.appendChild(tdDesc);
    tr.appendChild(tdAcct);
    tr.appendChild(tdAmount);
    recentTxTableBody.appendChild(tr);
  });
}

function renderBudgets() {
  budgetList.innerHTML = '';
  const entries = Object.entries(state.categoryBudgets);
  if (!entries.length) {
    budgetList.textContent = 'No budgets configured.';
    return;
  }
  const ul = document.createElement('ul');
  ul.style.fontSize = '0.8rem';
  entries.forEach(([cat,amt]) => {
    const li = document.createElement('li');
    li.textContent = `${cat}: ${amt.toFixed(2)}`;
    ul.appendChild(li);
  });
  budgetList.appendChild(ul);
}

function renderCategories() {
  const todayISO = getTodayISO();
  const agg = {};
  for (const tx of state.transactions) {
    if (!isSameMonth(tx.dateISO, todayISO)) continue;
    if (!agg[tx.category]) agg[tx.category] = { spent: 0, income: 0 };
    if (tx.amount < 0) agg[tx.category].spent += tx.amount;
    else agg[tx.category].income += tx.amount;
  }

  const entries = Object.entries(agg)
    .sort((a,b)=>Math.abs(b[1].spent) - Math.abs(a[1].spent));

  categoriesList.innerHTML = '';
  if (!entries.length) {
    categoriesList.textContent = 'No data for this month.';
    return;
  }

  entries.forEach(([cat, vals]) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.style.margin = '0 0 0.5rem';
    const spent = Math.abs(vals.spent);
    const income = vals.income;
    const net = vals.income + vals.spent;
    const budget = state.categoryBudgets[cat] || 0;

    let budgetText = '';
    if (budget > 0) {
      const usage = spent / budget;
      const pct = (usage * 100).toFixed(0);
      let color = '#2e7d32';
      if (usage > 1) color = '#c62828';
      else if (usage > 0.8) color = '#ff8f00';
      card.style.borderLeft = `4px solid ${color}`;
      budgetText = ` | Budget: ${budget.toFixed(2)} (${pct}% used)`;
    }

    card.innerHTML = `
      <strong>${cat}</strong><br>
      Spent: ${spent.toFixed(2)} |
      Income: ${income.toFixed(2)} |
      Net: ${net.toFixed(2)}${budgetText}
    `;
    categoriesList.appendChild(card);
  });
}

function renderSettings() {
  forecastDaysInput.value = state.settings.forecastDays;
  warningBufferInput.value = state.settings.warningBuffer;
  renderBudgets();
}

function renderAll() {
  renderAccounts();
  renderTransactions();
  renderOverview();
  renderCategories();
  renderSettings();
}

// ---------- Boot ----------
window.addEventListener('DOMContentLoaded', () => {
  initAuth();
});
